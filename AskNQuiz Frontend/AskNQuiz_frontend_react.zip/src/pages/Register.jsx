import { useState } from "react";
import Card from "../components/Card";
import { registerUser } from "../api/auth";

export default function Register() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "Student",
    admissionDate: new Date().toISOString().slice(0, 10) + "T00:00:00",
  });
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const onChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const onSubmit = async (e) => {
    e.preventDefault();
    setMsg("");
    setLoading(true);
    try {
      const data = await registerUser(form);
      setMsg("✅ Registered in .NET and created Student in Spring. UserId=" + (data?.userId ?? "(check response)"));
    } catch (err) {
      const txt = err?.response?.data || err?.message || "Unknown error";
      setMsg("❌ Register failed: " + txt);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 520, margin: "24px auto", padding: "0 12px" }}>
      <Card title="Register (calls .NET → then .NET calls Spring /students/register)">
        <form onSubmit={onSubmit} style={{ display: "grid", gap: 10 }}>
          <label>
            Name
            <input name="name" value={form.name} onChange={onChange} placeholder="Your name" style={{ width: "100%" }} />
          </label>
          <label>
            Email
            <input name="email" value={form.email} onChange={onChange} placeholder="abc@gmail.com" style={{ width: "100%" }} />
          </label>
          <label>
            Password
            <input name="password" type="password" value={form.password} onChange={onChange} placeholder="Test@123" style={{ width: "100%" }} />
          </label>
          <label>
            Role
            <select name="role" value={form.role} onChange={onChange} style={{ width: "100%" }}>
              <option>Student</option>
              <option>Teacher</option>
              <option>Admin</option>
            </select>
          </label>
          <label>
            Admission Date
            <input name="admissionDate" value={form.admissionDate} onChange={onChange} style={{ width: "100%" }} />
            <small style={{ opacity: 0.7 }}>Format: YYYY-MM-DDT00:00:00</small>
          </label>

          <button disabled={loading}>{loading ? "Registering..." : "Register"}</button>
        </form>

        {msg ? <p style={{ marginTop: 12 }}>{msg}</p> : null}
      </Card>
    </div>
  );
}
